#ifndef DatalogProgram_h
#include <iostream>
#include <vector>
#include <string>
#include <sstream>
#include <set>
#include "Predicate.h"
#include "Rule.h"

class DatalogProgram {
private:

std::vector<Predicate> schemeVector;
std::vector<Predicate> factVector;
std::vector<Predicate> queryVector;
std::vector<Rule> ruleVector;

std::set<std::string> domain;


public:

DatalogProgram();

void addScheme(Predicate scheme);
void addFact(Predicate fact);
void addQuery(Predicate query);
void addRule(Rule rule);
std::string toString();
void addDomain(std::string domainString);

void printContents();


    

};

#endif /* DatalogProgramr_h */